README FOR HIDREMOTE SDK
========================

HIDRemote
---------
Contains the HIDRemote class. For the latest version of this class and
documentation, please visit http://www.iospirit.com/developers/hidremote/


Example
-------
Contains a sample application showing the use of HIDRemote class. 


Documentation
-------------
Please visit http://www.iospirit.com/developers/hidremote/ for a guide
and documentation.
