#ifndef WINUTILS_H
#define WINUTILS_H


namespace WinUtils
{
  bool getPowerManagementPrivileges();
}

#endif // WINUTILS_H
