#ifndef OPENGLDETECT_H
#define OPENGLDETECT_H

void detectOpenGLEarly();
void detectOpenGLLate();

#endif // OPENGLDETECT_H
