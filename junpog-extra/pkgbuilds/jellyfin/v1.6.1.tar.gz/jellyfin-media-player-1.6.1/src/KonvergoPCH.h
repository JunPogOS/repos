
#if defined(__cplusplus)
#include <Qt>
#include <QString>
#include <QList>
#include <QVariant>
#include <QObject>
#include <QWidget>
#endif
