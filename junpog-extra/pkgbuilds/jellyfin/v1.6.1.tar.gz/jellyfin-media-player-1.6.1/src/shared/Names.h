//
// Created by Tobias Hieta on 11/09/15.
//

#ifndef NAMES_H
#define NAMES_H

#include <QString>

namespace Names
{
  QString MainName();
  QString HelperName();
};

#endif //NAMES_H
